/*
 * Author: Robert Beauchamp
 * Date started: 6/15/2023
 * Date Completed: 
 * 
 * step 1: define height and width parameters
 * step 2: generate math logic to find perimeter and area.
 * step 3: ???
 * step 4: profit
 */
public class rectangleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
