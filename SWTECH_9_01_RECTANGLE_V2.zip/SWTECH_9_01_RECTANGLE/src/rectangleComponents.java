
public class rectangleComponents {

}
